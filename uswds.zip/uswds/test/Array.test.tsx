import { arrayTests } from '@rjsf/snapshot-tests';

import Form from '../src';

arrayTests(Form);
