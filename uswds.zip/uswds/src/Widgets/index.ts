import widgets, { generateWidgets } from './Widgets'; // Assuming Widgets.tsx is in the same directory

// Re-export the named function
export { generateWidgets };

// Re-export the default object
export default widgets;
